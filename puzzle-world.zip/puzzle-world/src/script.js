// Puzzle questions
const puzzles = [
    { question: "What goes up and never comes down?", answer: "Age" },
    // Add more puzzles here
];

// Game variables
let currentLevel = 1;
let timeLeft = 300;
let currentPuzzle = 0;

const levelElement = document.getElementById('level');
const timerElement = document.getElementById('time');
const puzzleElement = document.getElementById('puzzle');
const answerInput = document.getElementById('answer');
const resultElement = document.getElementById('result');
const nextLevelButton = document.getElementById('nextLevel');

function startTimer() {
    const timerInterval = setInterval(() => {
        timeLeft--;
        timerElement.textContent = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            showResult("Time's up! You failed this level.");
        }
    }, 1000);
}

function showPuzzle() {
    if (currentPuzzle < puzzles.length) {
        puzzleElement.textContent = puzzles[currentPuzzle].question;
    } else {
        showResult("Congratulations! You've completed all puzzles.");
    }
}

function checkAnswer() {
    const userAnswer = answerInput.value.trim().toLowerCase();
    const correctAnswer = puzzles[currentPuzzle].answer.toLowerCase();
    
    if (userAnswer === correctAnswer) {
        resultElement.textContent = "Correct!";
        currentPuzzle++;
        showPuzzle();
        answerInput.value = '';
    } else {
        resultElement.textContent = "Incorrect. Try again.";
    }
}

function showResult(message) {
    resultElement.textContent = message;
    nextLevelButton.style.display = 'block';
}

document.getElementById('submit').addEventListener('click', checkAnswer);
nextLevelButton.addEventListener('click', () => {
    currentLevel++;
    levelElement.textContent = currentLevel;
    currentPuzzle = 0;
    timeLeft = 300;
    timerElement.textContent = timeLeft;
    nextLevelButton.style.display = 'none';
    showPuzzle();
});

startTimer();
showPuzzle();
